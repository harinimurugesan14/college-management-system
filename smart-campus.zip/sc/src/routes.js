const express = require('express');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const M = require('./models');
const { auth, allow } = require('./middleware');
const crud = require('./crud');
const { wrap } = crud;

const router = express.Router();
const staff = ['admin', 'faculty'];
const own = field => req => (req.user.role === 'student' ? { [field]: req.user.id } : {});

// ---- Auth
const authR = express.Router();
authR.post('/login', rateLimit({ windowMs: 15 * 60 * 1000, max: 30 }), wrap(async (req, res) => {
  const { email, password } = req.body || {};
  if (typeof email !== 'string' || typeof password !== 'string') return res.status(400).json({ message: 'Email and password required' });
  const user = await M.User.findOne({ email: email.toLowerCase().trim() }).select('+password');
  if (!user || !user.active || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ message: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES || '1d' });
  res.json({ token, user });
}));
authR.get('/me', auth, wrap(async (req, res) => res.json(await M.User.findById(req.user.id).populate('department'))));
router.use('/auth', authR);

// ---- Master data
router.use('/departments', crud(M.Department, { search: ['name', 'code'], populate: 'head' }));
router.use('/courses', crud(M.Course, { search: ['name', 'code'], filters: ['department', 'faculty', 'semester'], populate: 'department faculty' }));
router.use('/students', crud(M.User, { base: { role: 'student' }, search: ['name', 'email', 'rollNo'], filters: ['department', 'semester'], populate: 'department', read: staff, create: ['admin'] }));
router.use('/faculty', crud(M.User, { base: { role: 'faculty' }, search: ['name', 'email'], filters: ['department'], populate: 'department' }));
router.use('/timetable', crud(M.Timetable, { filters: ['course', 'department', 'semester', 'day'], populate: 'course', create: ['admin'], update: ['admin'] }));

// ---- Attendance
const STATUS = ['present', 'absent', 'late'];
router.post('/attendance/bulk', auth, allow(...staff), wrap(async (req, res) => {
  const { course, date, records } = req.body || {};
  const d = new Date(date);
  if (typeof course !== 'string' || isNaN(d) || !Array.isArray(records) || !records.length) return res.status(400).json({ message: 'course, date and records are required' });
  if (!records.every(x => x && typeof x.student === 'string' && STATUS.includes(x.status))) return res.status(400).json({ message: 'Invalid attendance records' });
  d.setUTCHours(0, 0, 0, 0);
  await M.Attendance.bulkWrite(records.map(x => ({
    updateOne: { filter: { course, student: x.student, date: d }, update: { $set: { status: x.status, markedBy: req.user.id } }, upsert: true }
  })));
  res.json({ message: 'Attendance saved', count: records.length });
}));
router.use('/attendance', crud(M.Attendance, { filters: ['course', 'student', 'date', 'status'], populate: 'course student', scope: own('student'), create: staff, update: staff }));

// ---- Marks and results
router.use('/marks', crud(M.Mark, { filters: ['course', 'student', 'exam'], populate: 'course student', scope: own('student'), create: staff, update: staff, remove: staff }));
const grade = p => (p >= 90 ? 'O' : p >= 80 ? 'A+' : p >= 70 ? 'A' : p >= 60 ? 'B' : p >= 50 ? 'C' : 'F');
router.get('/results/:studentId', auth, wrap(async (req, res) => {
  if (req.user.role === 'student' && req.params.studentId !== req.user.id) return res.status(403).json({ message: 'Forbidden' });
  const marks = await M.Mark.find({ student: req.params.studentId }).populate('course', 'name code credits');
  const by = {};
  for (const m of marks) {
    if (!m.course) continue;
    const k = m.course.id;
    by[k] = by[k] || { course: m.course, score: 0, max: 0 };
    by[k].score += m.score; by[k].max += m.max;
  }
  const results = Object.values(by).map(x => { const percent = +((x.score / x.max) * 100).toFixed(2); return { ...x, percent, grade: grade(percent), passed: percent >= 50 }; });
  res.json({ results, overall: results.length ? +(results.reduce((a, x) => a + x.percent, 0) / results.length).toFixed(2) : 0 });
}));

// ---- Leave
router.use('/leaves', crud(M.Leave, {
  filters: ['status', 'user'], populate: 'user',
  scope: req => (req.user.role === 'admin' ? {} : req.user.role === 'faculty' ? { $or: [{ user: req.user.id }, { role: 'student' }] } : { user: req.user.id }),
  create: ['faculty', 'student'], update: staff, remove: ['admin'],
  shape: (req, b, isNew) => isNew
    ? { from: b.from, to: b.to, reason: b.reason, user: req.user.id, role: req.user.role, status: 'pending' }
    : { status: b.status, reviewedBy: req.user.id }
}));

// ---- Notifications
router.use('/notifications', crud(M.Notification, {
  filters: ['audience'], scope: req => (req.user.role === 'admin' ? {} : { audience: { $in: ['all', req.user.role] } }),
  create: staff, update: ['admin'],
  shape: (req, b, isNew) => ({ title: b.title, message: b.message, audience: b.audience, ...(isNew ? { createdBy: req.user.id } : {}) })
}));

// ---- Analytics
router.get('/analytics', auth, allow(...staff), wrap(async (_req, res) => {
  const [students, faculty, courses, departments, pendingLeaves, att, byDepartment] = await Promise.all([
    M.User.countDocuments({ role: 'student' }), M.User.countDocuments({ role: 'faculty' }),
    M.Course.countDocuments(), M.Department.countDocuments(), M.Leave.countDocuments({ status: 'pending' }),
    M.Attendance.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
    M.User.aggregate([
      { $match: { role: 'student' } }, { $group: { _id: '$department', count: { $sum: 1 } } },
      { $lookup: { from: 'departments', localField: '_id', foreignField: '_id', as: 'd' } },
      { $project: { _id: 0, count: 1, name: { $ifNull: [{ $arrayElemAt: ['$d.name', 0] }, 'Unassigned'] } } }
    ])
  ]);
  const c = Object.fromEntries(att.map(x => [x._id, x.count]));
  const total = (c.present || 0) + (c.absent || 0) + (c.late || 0);
  res.json({ students, faculty, courses, departments, pendingLeaves, attendanceRate: total ? +((((c.present || 0) + (c.late || 0)) / total) * 100).toFixed(1) : 0, studentsByDepartment: byDepartment });
}));

module.exports = router;
