const express = require('express');
const { auth, allow } = require('./middleware');

const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const ALL = ['admin', 'faculty', 'student'];

function crud(Model, o = {}) {
  const {
    search = [], filters = [], populate = '', base = {},
    read = ALL, create = ['admin'], update = ['admin'], remove = ['admin'],
    scope = () => ({}), shape = (_req, b) => b
  } = o;
  const r = express.Router();
  r.use(auth);
  const find = (q) => { const x = Model.find(q); if (populate) x.populate(populate); return x; };

  r.get('/', allow(...read), wrap(async (req, res) => {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
    const q = { ...scope(req), ...base };
    for (const k of filters) if (typeof req.query[k] === 'string' && req.query[k]) q[k] = req.query[k];
    if (typeof req.query.q === 'string' && req.query.q && search.length) {
      q.$and = [{ $or: search.map(f => ({ [f]: new RegExp(esc(req.query.q), 'i') })) }];
    }
    const s = typeof req.query.sort === 'string' && /^-?[a-zA-Z]+$/.test(req.query.sort) ? req.query.sort : '-createdAt';
    const [items, total] = await Promise.all([
      find(q).sort(s).skip((page - 1) * limit).limit(limit),
      Model.countDocuments(q)
    ]);
    res.json({ items, total, page, pages: Math.ceil(total / limit) });
  }));

  r.get('/:id', allow(...read), wrap(async (req, res) => {
    const doc = await find({ _id: req.params.id, ...scope(req), ...base }).findOne();
    if (!doc) return res.status(404).json({ message: 'Not found' });
    res.json(doc);
  }));

  r.post('/', allow(...create), wrap(async (req, res) => {
    const doc = await Model.create({ ...shape(req, req.body || {}, true), ...base });
    res.status(201).json(doc);
  }));

  r.put('/:id', allow(...update), wrap(async (req, res) => {
    const doc = await Model.findOne({ _id: req.params.id, ...scope(req), ...base });
    if (!doc) return res.status(404).json({ message: 'Not found' });
    doc.set({ ...shape(req, req.body || {}, false), ...base });
    await doc.save();
    res.json(doc);
  }));

  r.delete('/:id', allow(...remove), wrap(async (req, res) => {
    const doc = await Model.findOneAndDelete({ _id: req.params.id, ...base });
    if (!doc) return res.status(404).json({ message: 'Not found' });
    res.json({ message: 'Deleted' });
  }));
  return r;
}
crud.wrap = wrap;
module.exports = crud;
