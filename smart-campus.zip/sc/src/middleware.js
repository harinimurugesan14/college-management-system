const jwt = require('jsonwebtoken');
const { User } = require('./models');

exports.auth = async (req, res, next) => {
  try {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : null;
    if (!token) return res.status(401).json({ message: 'Authentication required' });
    const p = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(p.id);
    if (!user || !user.active) return res.status(401).json({ message: 'Account unavailable' });
    req.user = { id: user.id, role: user.role, name: user.name };
    next();
  } catch (e) {
    res.status(401).json({ message: 'Invalid or expired token' });
  }
};

exports.allow = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : res.status(403).json({ message: 'Forbidden' });

// eslint-disable-next-line no-unused-vars
exports.errorHandler = (err, req, res, next) => {
  if (err.name === 'ValidationError') return res.status(400).json({ message: Object.values(err.errors).map(e => e.message).join(', ') });
  if (err.name === 'CastError') return res.status(400).json({ message: `Invalid ${err.path}` });
  if (err.code === 11000) return res.status(409).json({ message: 'Duplicate value: ' + Object.keys(err.keyValue || {}).join(', ') });
  console.error(err);
  res.status(500).json({ message: 'Internal server error' });
};
