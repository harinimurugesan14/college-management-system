const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { Schema, model } = mongoose;
const ref = (name, extra = {}) => ({ type: Schema.Types.ObjectId, ref: name, ...extra });
const day = v => { const d = new Date(v); d.setUTCHours(0, 0, 0, 0); return d; };

const userSchema = new Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, minlength: 8, select: false },
  role: { type: String, enum: ['admin', 'faculty', 'student'], required: true },
  department: ref('Department'),
  rollNo: { type: String, trim: true },
  semester: Number,
  phone: String,
  active: { type: Boolean, default: true }
}, { timestamps: true });
userSchema.pre('save', async function () {
  if (this.isModified('password')) this.password = await bcrypt.hash(this.password, 10);
});
userSchema.set('toJSON', { transform: (_d, ret) => { delete ret.password; delete ret.__v; return ret; } });

const Department = model('Department', new Schema({
  name: { type: String, required: true, unique: true, trim: true },
  code: { type: String, required: true, unique: true, uppercase: true, trim: true },
  head: ref('User')
}, { timestamps: true }));

const Course = model('Course', new Schema({
  name: { type: String, required: true, trim: true },
  code: { type: String, required: true, unique: true, uppercase: true, trim: true },
  department: ref('Department', { required: true }),
  faculty: ref('User'),
  credits: { type: Number, min: 0, default: 3 },
  semester: { type: Number, min: 1, max: 12 }
}, { timestamps: true }));

const Timetable = model('Timetable', new Schema({
  course: ref('Course', { required: true }),
  department: ref('Department'),
  semester: Number,
  day: { type: String, enum: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], required: true },
  startTime: { type: String, required: true, match: /^([01]\d|2[0-3]):[0-5]\d$/ },
  endTime: { type: String, required: true, match: /^([01]\d|2[0-3]):[0-5]\d$/ },
  room: String
}, { timestamps: true }));

const attSchema = new Schema({
  course: ref('Course', { required: true }),
  student: ref('User', { required: true }),
  date: { type: Date, required: true, set: day },
  status: { type: String, enum: ['present', 'absent', 'late'], required: true },
  markedBy: ref('User')
}, { timestamps: true });
attSchema.index({ course: 1, student: 1, date: 1 }, { unique: true });
const Attendance = model('Attendance', attSchema);

const markSchema = new Schema({
  student: ref('User', { required: true }),
  course: ref('Course', { required: true }),
  exam: { type: String, required: true, trim: true },
  score: { type: Number, required: true, min: 0 },
  max: { type: Number, required: true, min: 1, default: 100 }
}, { timestamps: true });
markSchema.index({ student: 1, course: 1, exam: 1 }, { unique: true });
markSchema.pre('validate', function () {
  if (this.score > this.max) this.invalidate('score', 'Score cannot exceed max');
});
const Mark = model('Mark', markSchema);

const Leave = model('Leave', new Schema({
  user: ref('User', { required: true }),
  role: { type: String, enum: ['faculty', 'student'], required: true },
  from: { type: Date, required: true },
  to: { type: Date, required: true },
  reason: { type: String, required: true, trim: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  reviewedBy: ref('User')
}, { timestamps: true }));

const Notification = model('Notification', new Schema({
  title: { type: String, required: true, trim: true },
  message: { type: String, required: true },
  audience: { type: String, enum: ['all', 'admin', 'faculty', 'student'], default: 'all' },
  createdBy: ref('User')
}, { timestamps: true }));

module.exports = { User: model('User', userSchema), Department, Course, Timetable, Attendance, Mark, Leave, Notification };
